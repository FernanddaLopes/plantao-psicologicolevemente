PASSO A PASSO PARA PUBLICAR SEU SITE NO GITHUB PAGES

1) FAZER UPLOAD DOS ARQUIVOS NO REPOSITÓRIO
-------------------------------------------
- Acesse o site https://github.com e entre com seu usuário: FernanddaLopes
- Vá até o repositório chamado: plantao-psicologicolevemente
- Clique na aba "Add file" > "Upload files"
- Selecione os arquivos: index.html e README.txt
- Clique em "Commit changes" para salvar

2) ATIVAR O GITHUB PAGES
------------------------
- No repositório, clique na aba "Settings"
- Role a página até encontrar "Pages"
- Em "Source", selecione "Deploy from a branch"
- Escolha a branch "main" e clique em "Save"
- Aguarde alguns segundos até aparecer o link do site

3) LINK FINAL DO SITE
---------------------
Seu site ficará disponível em:

https://FernanddaLopes.github.io/plantao-psicologicolevemente/

Você pode compartilhar esse link com qualquer pessoa. O site estará público e acessível!

DICA: Se quiser mudar o nome do site, basta renomear o repositório e repetir os passos acima.
